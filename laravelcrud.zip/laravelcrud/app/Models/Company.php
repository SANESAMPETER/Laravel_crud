<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    protected $fillable = ['name','email','address']; // interaction with the database
    // $fillable is an array in laravel that contains all the field in a table 
    //that can be filled using mass assignment. to 
}
